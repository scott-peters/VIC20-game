
 Please note that not all decrunchers in this folder have been updated
to use the new file format for crunched files that exomizer 3 generates by
default. The `exostreamdecr1.s` and `exostreamdecr2.s` have NOT yet been
updated.

 To generate files that are compatible with exomizer 2 you must now add the
flag -P0 to the exomizer commandline.

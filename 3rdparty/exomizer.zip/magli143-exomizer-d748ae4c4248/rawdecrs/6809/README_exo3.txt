
 Please note that the decrunchers in this folder has not yet been updated to
use the new file format for crunched files that exomizer 3 generates by
default.

 To generate files that are compatible with exomizer 2 you must now add the
flag -P0 to the commandline.
